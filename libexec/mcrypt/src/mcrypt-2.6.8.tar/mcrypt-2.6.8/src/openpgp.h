int pgp_encrypt_wrap( const char *infile, const char *outfile, char *pass );
int pgp_decrypt_wrap( const char *infile, const char *outfile, char *pass );
