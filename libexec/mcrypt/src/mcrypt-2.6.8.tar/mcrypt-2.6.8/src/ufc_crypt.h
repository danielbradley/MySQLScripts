int gen_crypt(void *keyword, int key_size, unsigned char *password, int plen);
