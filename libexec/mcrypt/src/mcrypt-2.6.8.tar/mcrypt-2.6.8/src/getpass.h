char * _mcrypt_getpass(const char *prompt);
