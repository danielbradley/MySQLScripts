int ppopen (const char *command, FILE **ch_stdin, FILE **ch_stdout);
